package ClassTask3.Task3;

public class Zoo {
    public static void main(String[] args) {
        Animal animal1 = new Animal("小动物", 4);
        animal1.move();
        Fish fish = new Fish("Fish1");
        fish.move();
    }
}
