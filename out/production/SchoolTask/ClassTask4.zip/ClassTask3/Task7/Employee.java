package ClassTask3.Task7;

public class Employee {
    private String name;
    private int month;

    Employee(String name1, int month1){
        name = name1;
        month = month1;
    }

    public double getSalary(int month){
        return 0;
    }

    public int getMonth(){
        return month;
    }

    public String getName(){
        return name;
    }
}
