package ClassTask3.Task1;

public class Teacher {
    String name;
    int age;
    String sex;
    double salary;

    public void addSalary5000() {
        salary += 5000;
    }
}
